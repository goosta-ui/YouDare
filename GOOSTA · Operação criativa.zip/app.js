const API = "port/5037".startsWith("__") ? "" : "port/5037";
let state = {teams:[],projects:[],deliverables:[],coverage:[]};
let edit = null;
const $ = s => document.querySelector(s);
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = s => s ? `${s.slice(8,10)}/${s.slice(5,7)}/${s.slice(0,4)}` : "—";
const today = () => new Intl.DateTimeFormat("en-CA",{timeZone:"America/Sao_Paulo",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
const monthName = s => new Date(Number(s.slice(0,4)),Number(s.slice(5,7))-1,1).toLocaleDateString("pt-BR",{month:"short"}).replace(".","");
const team = id => state.teams.find(t=>t.id===Number(id));
const project = id => state.projects.find(p=>p.id===Number(id));
const options = (list, chosen) => list.map(x=>`<option value="${esc(x.value)}" ${String(x.value)===String(chosen)?"selected":""}>${esc(x.label)}</option>`).join("");
const teamOptions = (chosen, empty=false) => options([...(empty?[{value:"",label:"Selecione"}]:[]),...state.teams.map(t=>({value:t.id,label:t.name}))],chosen);
const projectOptions = chosen => options([{value:"",label:"Selecione"},...state.projects.map(p=>({value:p.id,label:p.title}))],chosen);
const field = (label,name,value="",type="text",extra="") => `<label class="field">${label}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const select = (label,name,values,chosen) => `<label class="field">${label}<select name="${name}" required>${options(values,chosen)}</select></label>`;
const notes = v => `<label class="field">Observações<textarea name="notes" placeholder="Brief, dependências, decisões...">${esc(v)}</textarea></label>`;
const statuses = ["Planejado","Em criação","Em aprovação","Concluído","Pausado"];
const empty = (title,detail) => `<div class="empty-panel"><strong>${title}</strong>${detail}</div>`;

async function req(path,method="GET",body) {
  const r=await fetch(`${API}/api/${path}`,{method,headers:body?{"Content-Type":"application/json"}:{},body:body?JSON.stringify(body):undefined});
  let v=await r.json(); if(!r.ok) throw Error(v.error || "Não foi possível salvar."); return v;
}
async function reload(){state=await req("data"); render()}
function notify(message,error=false){const el=$("#feedback");el.textContent=message;el.classList.toggle("error",error);setTimeout(()=>{if(el.textContent===message)el.textContent=""},5500)}
function showView(id){
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===id));
  document.querySelectorAll(".nav").forEach(v=>v.classList.toggle("active",v.dataset.view===id));
  $("#location").textContent=({overview:"VISÃO GERAL",projects:"PROJETOS",team:"EQUIPES",method:"MÉTODO"})[id];
  $("#main").scrollTop=0;
}
function render(){
  $("#filter-team").innerHTML='<option value="">Todas</option>'+teamOptions("");
  renderOverview();renderProjects();renderTeams();
}
function renderOverview(){
  const m=$("#month").value||today().slice(0,7), start=m+"-01", end=m+"-31";
  const delivered=state.deliverables.filter(d=>d.delivered_at?.startsWith(m));
  const due=state.deliverables.filter(d=>d.due_date>=start&&d.due_date<=end);
  const onTime=delivered.filter(d=>d.delivered_at<=d.due_date).length;
  const active=state.projects.filter(p=>!["Concluído","Pausado"].includes(p.status));
  const overdue=state.deliverables.filter(d=>!d.delivered_at&&d.due_date<today()).length;
  $("#kpis").innerHTML=[
    ["Entregas do mês",delivered.length,"Data efetiva de conclusão"],
    ["No prazo",delivered.length?`${Math.round(100*onTime/delivered.length)}%`:"—",`${onTime} de ${delivered.length} entregas`],
    ["Projetos ativos",active.length,"Planejados, em criação e aprovação"],
    ["Entregas atrasadas",overdue,"Pendentes após o prazo"]
  ].map(([a,b,c])=>`<div class="kpi"><small>${a}</small><strong>${b}</strong><em>${c}</em></div>`).join("");
  const months=Array.from({length:6},(_,i)=>{const [y,mo]=m.split("-").map(Number);const d=new Date(y,mo-6+i,1);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`});
  const counts=months.map(x=>state.deliverables.filter(d=>d.delivered_at?.startsWith(x)).length), max=Math.max(1,...counts);
  $("#chart").innerHTML=months.map((x,i)=>`<div class="bar-col ${x===m?"current":""}"><strong>${counts[i]}</strong><div class="bar-track"><div class="bar" style="height:${Math.max(3,counts[i]/max*100)}%"></div></div><span>${monthName(x)}</span></div>`).join("");
  $("#capacity").innerHTML=state.teams.map(t=>{
    const n=active.filter(p=>p.team_id===t.id).length;
    const temporary=state.coverage.filter(c=>c.origin_team===t.id&&c.start_date<=today()&&c.end_date>=today()).length;
    return `<div class="capacity-row"><div><b>${esc(t.name)}</b><small>${esc(t.art||"DA a definir")} + ${esc(t.copy||"redator(a) a definir")}</small></div><div><strong>${n} ${n===1?"projeto":"projetos"}</strong><small>${temporary?temporary+" profissional(is) em cobertura":"Sem saída em cobertura"}</small></div></div>`;
  }).join("");
  const upcoming=state.deliverables.filter(d=>!d.delivered_at).sort((a,b)=>a.due_date.localeCompare(b.due_date)).slice(0,7);
  $("#upcoming").innerHTML=upcoming.length?upcoming.map(d=>`<div class="upcoming-row"><div><b>${esc(d.title)}</b><small>${esc(project(d.project_id)?.title||"Projeto removido")}</small></div><span class="chip">${esc(team(project(d.project_id)?.team_id)?.name||"")}</span><span class="date ${d.due_date<today()?"late":""}">${fmt(d.due_date)}</span></div>`).join(""):empty("Nenhuma entrega pendente.","Cadastre um projeto e suas peças para acompanhar os próximos prazos.");
}
function renderProjects(){
  const filtered=state.projects.filter(p=>(!$("#filter-team").value||p.team_id===Number($("#filter-team").value))&&(!$("#filter-status").value||p.status===$("#filter-status").value));
  $("#project-list").innerHTML=filtered.length?filtered.map(p=>{
    const ds=state.deliverables.filter(d=>d.project_id===p.id).sort((a,b)=>a.due_date.localeCompare(b.due_date));
    const cs=state.coverage.filter(c=>c.project_id===p.id);
    return `<article class="project-card"><div class="project-head"><div><h2>${esc(p.title)}</h2><p>${esc(team(p.team_id)?.name)} · ${fmt(p.start_date)} a ${fmt(p.due_date)}</p></div><div class="project-head-actions"><span class="chip ${p.status==="Pausado"?"paused":""}">${esc(p.status)}</span><button class="link-button" data-action="edit-project" data-id="${p.id}">Editar</button><button class="link-button danger" data-action="delete-project" data-id="${p.id}">Excluir</button></div></div><p class="project-meta">${ds.length} ${ds.length===1?"entrega":"entregas"} · ${ds.filter(d=>d.delivered_at).length} concluídas${cs.length?` · ${cs.length} cobertura(s)`:""}</p>${p.notes?`<p class="project-notes">${esc(p.notes)}</p>`:""}<div class="deliverable-list">${ds.length?ds.map(d=>`<div class="deliverable-row"><div><b>${esc(d.title)}</b>${d.notes?`<small>${esc(d.notes)}</small>`:""}</div><span class="due-note ${!d.delivered_at&&d.due_date<today()?"late":""}">Prazo ${fmt(d.due_date)}${d.delivered_at?` · entregue ${fmt(d.delivered_at)}`:""}</span><button class="link-button" data-action="edit-deliverable" data-id="${d.id}">${d.delivered_at?"Editar":"Concluir / editar"}</button><button class="link-button danger" data-action="delete-deliverable" data-id="${d.id}">Excluir</button></div>`).join(""):`<p class="empty">Ainda sem entregas cadastradas.</p>`}</div><button class="text-button" data-open="deliverable" data-project="${p.id}">+ Adicionar entrega</button></article>`;
  }).join(""):empty("Nenhum projeto nesta seleção.","Crie a primeira campanha ou altere os filtros.");
}
function renderTeams(){
  const active=state.projects.filter(p=>!["Concluído","Pausado"].includes(p.status));
  $("#team-cards").innerHTML=state.teams.map(t=>`<article class="team-card"><div class="team-top"><h2>${esc(t.name)}</h2><button class="link-button" data-action="edit-team" data-id="${t.id}">Editar dupla</button></div><dl><dt>Direção de arte</dt><dd>${esc(t.art||"Não cadastrado")}</dd><dt>Redação</dt><dd>${esc(t.copy||"Não cadastrado")}</dd></dl><footer>${active.filter(p=>p.team_id===t.id).length} projeto(s) ativo(s) · ${state.coverage.filter(c=>c.origin_team===t.id&&c.start_date<=today()&&c.end_date>=today()).length} pessoa(s) cedida(s) hoje</footer></article>`).join("");
  $("#coverage-list").innerHTML=state.coverage.length?state.coverage.map(c=>`<div class="coverage-row"><div><b>${esc(c.person)}</b><small>${esc(c.role)} · origem: ${esc(team(c.origin_team)?.name||"Externo / não informada")}</small></div><span>${esc(project(c.project_id)?.title||"Projeto removido")}</span><span class="coverage-period">${fmt(c.start_date)} a ${fmt(c.end_date)}${c.notes?`<small>${esc(c.notes)}</small>`:""}</span><button class="link-button danger" data-action="delete-coverage" data-id="${c.id}">Excluir</button></div>`).join(""):empty("Nenhuma cobertura registrada.","Ao ceder alguém, registre origem, destino, função e período.");
}
const methods=[
  ["Duplas proprietárias","Cada campanha tem uma dupla responsável do briefing à entrega. A pessoa de cobertura entra para resolver uma lacuna específica, mas a equipe de origem continua visível e o diretor criativo mantém a decisão final. Evita a sensação de que o projeto ficou sem dono."],
  ["Cobertura com escopo e saída","Antes de deslocar alguém, defina função, entregável, data de entrada, data de saída e quem faz o handoff. Cubra preferencialmente um marco fechado, não uma campanha inteira por tempo indeterminado. Depois, devolva contexto à dupla titular."],
  ["Ritual de capacidade semanal","Na segunda-feira, revise os próximos 10 dias úteis com as três duplas: entregas, aprovações externas, gargalos e ausências. Não empreste uma pessoa apenas porque a agenda parece livre; confira a etapa crítica de sua campanha de origem."],
  ["Brief e checkpoints comuns","Use um briefing mínimo para todas as campanhas: objetivo, público, ideia, canais, formatos, responsáveis, referências e critérios de aprovação. Faça checkpoints curtos em conceito, primeira rota e pré-entrega. Isso permite a entrada de um substituto sem reiniciar o raciocínio."],
  ["Medição por entrega, não por atividade","Cadastre cada peça ou pacote aprovado como entrega própria, com prazo e data efetiva. Acompanhe volume mensal e pontualidade, mas interprete junto com complexidade, retrabalho e qualidade. Cinco desdobramentos não equivalem necessariamente a cinco conceitos."]
];
$("#methods").innerHTML=methods.map((m,i)=>`<article class="method-item"><span class="num">0${i+1}</span><div><h2>${m[0]}</h2><p>${m[1]}</p></div></article>`).join("");
function openEditor(kind,id,projectId){
  edit={kind,id,projectId};let title="",html="",obj;
  if(kind==="team"){
    obj=team(id);title="Editar dupla";
    html=field("Nome da equipe","name",obj.name,"text","required maxlength=80")+field("Diretor(a) de arte","art",obj.art,"text","maxlength=100")+field("Redator(a)","copy",obj.copy,"text","maxlength=100");
  }else if(kind==="project"){
    obj=id?project(id):{};title=id?"Editar projeto":"Novo projeto";
    html=field("Projeto ou campanha","title",obj.title,"text","required maxlength=160")+`<div class="field-grid">${select("Equipe responsável","team_id",state.teams.map(t=>({value:t.id,label:t.name})),obj.team_id||1)}${select("Status","status",statuses.map(s=>({value:s,label:s})),obj.status||"Planejado")}</div><div class="field-grid">${field("Início","start_date",obj.start_date||today(),"date","required")}${field("Fim previsto","due_date",obj.due_date||"","date","required")}</div>`+notes(obj.notes);
  }else if(kind==="deliverable"){
    obj=id?state.deliverables.find(d=>d.id===id):{};title=id?"Editar entrega":"Nova entrega";
    html=id?`<p class="project-meta">Projeto: ${esc(project(obj.project_id)?.title)}</p>`:select("Projeto","project_id",state.projects.map(p=>({value:p.id,label:p.title})),projectId||state.projects[0]?.id);
    html+=field("Peça ou pacote","title",obj.title,"text","required maxlength=160")+`<div class="field-grid">${field("Prazo previsto","due_date",obj.due_date||"","date","required")}${field("Entrega efetiva (opcional)","delivered_at",obj.delivered_at||"","date")}</div>`+notes(obj.notes);
  }else{
    title="Registrar cobertura";html=select("Campanha que recebe","project_id",state.projects.map(p=>({value:p.id,label:p.title})),state.projects[0]?.id)+`<div class="field-grid">${select("Função","role",[{value:"Direção de arte",label:"Direção de arte"},{value:"Redação",label:"Redação"}],"Direção de arte")}${select("Equipe de origem","origin_team",[{value:"",label:"Externo / não informada"},...state.teams.map(t=>({value:t.id,label:t.name}))],"")}</div>`+field("Profissional","person","","text","required maxlength=100")+`<div class="field-grid">${field("Início da cobertura","start_date",today(),"date","required")}${field("Fim da cobertura","end_date","","date","required")}</div>`+notes("");
  }
  $("#dialog-kicker").textContent=kind.toUpperCase();
  $("#dialog-title").textContent=title;$("#fields").innerHTML=html;$("#form-error").textContent="";
  $("#editor").showModal();
}
$("#record-form").addEventListener("submit",async e=>{
  e.preventDefault();let v=Object.fromEntries(new FormData(e.currentTarget));
  try{
    if(edit.kind==="team")await req(`teams/${edit.id}`,"PUT",v);
    if(edit.kind==="project")await req(`projects${edit.id?"/"+edit.id:""}`,edit.id?"PUT":"POST",v);
    if(edit.kind==="deliverable")await req(`deliverables${edit.id?"/"+edit.id:""}`,edit.id?"PUT":"POST",v);
    if(edit.kind==="coverage")await req("coverage","POST",v);
    $("#editor").close();await reload();notify("Registro salvo.");
  }catch(err){$("#form-error").textContent=err.message}
});
document.addEventListener("click",async e=>{
  const nav=e.target.closest("[data-view]");if(nav){showView(nav.dataset.view);return}
  const open=e.target.closest("[data-open]");if(open){
    if((open.dataset.open==="deliverable"||open.dataset.open==="coverage")&&!state.projects.length){notify("Cadastre um projeto antes.",true);return}
    openEditor(open.dataset.open,null,open.dataset.project);return
  }
  const act=e.target.closest("[data-action]");if(!act)return;
  const id=Number(act.dataset.id),a=act.dataset.action;
  if(a.startsWith("edit-")){openEditor(a.slice(5),id);return}
  if(!confirm(a==="delete-project"?"Excluir este projeto e todas as suas entregas e coberturas?":"Excluir este registro?"))return;
  try{await req(`${a.slice(7)}${a==="delete-project"?"s":a==="delete-coverage"?"":"s"}/${id}`,"DELETE");await reload();notify("Registro excluído.")}
  catch(err){notify(err.message,true)}
});
$("#close").onclick=$("#cancel").onclick=()=>$("#editor").close();
$("#month").value=today().slice(0,7);
$("#month").addEventListener("change",renderOverview);
$("#filter-team").addEventListener("change",renderProjects);
$("#filter-status").addEventListener("change",renderProjects);
$("#today").textContent=new Date().toLocaleDateString("pt-BR",{timeZone:"America/Sao_Paulo",day:"2-digit",month:"short",year:"numeric"});
$("#export").addEventListener("click",()=>{
  const cols=["Equipe","Diretor(a) de arte","Redator(a)","Campanha","Início","Fim previsto","Status","Observações da campanha","Entrega","Prazo da entrega","Data efetiva","Observações da entrega"];
  const rows=state.projects.flatMap(p=>{
    const t=team(p.team_id),ds=state.deliverables.filter(d=>d.project_id===p.id);
    return (ds.length?ds:[{}]).map(d=>[t?.name||"",t?.art||"",t?.copy||"",p.title,p.start_date,p.due_date,p.status,p.notes,d.title||"",d.due_date||"",d.delivered_at||"",d.notes||""]);
  });
  const quote=v=>`"${String(v??"").replaceAll('"','""')}"`;
  const csv="\uFEFF"+[cols,...rows].map(r=>r.map(quote).join(";")).join("\r\n");
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="operacao-criativa-goosta.csv";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});
reload().catch(e=>notify("Não foi possível carregar os dados: "+e.message,true));
